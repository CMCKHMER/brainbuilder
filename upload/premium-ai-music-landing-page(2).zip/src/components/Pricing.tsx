import { useState } from "react";
import { motion } from "framer-motion";
import { Check, Sparkles, ArrowRight } from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { Button } from "./ui/Button";
import { cn } from "@/utils/cn";

type Plan = {
  name: string;
  tagline: string;
  monthly: number;
  yearly: number;
  features: string[];
  cta: string;
  popular?: boolean;
  accent: string;
};

const PLANS: Plan[] = [
  {
    name: "Starter",
    tagline: "For curious creators testing the waters.",
    monthly: 0,
    yearly: 0,
    features: [
      "10 renders / month",
      "Up to 5 min per upload",
      "3 version types",
      "MP3 export",
      "Community support",
    ],
    cta: "Start free",
    accent: "from-zinc-500/20 to-zinc-500/10",
  },
  {
    name: "Pro",
    tagline: "For working producers and creators who ship.",
    monthly: 24,
    yearly: 19,
    features: [
      "Unlimited renders",
      "Up to 2 hours per upload",
      "All version types + stems",
      "Lossless WAV + FLAC export",
      "Smart mastering (LUFS)",
      "Priority GPU queue",
      "Email support",
    ],
    cta: "Go Pro",
    popular: true,
    accent: "from-brand-500/30 to-fuchsia-500/20",
  },
  {
    name: "Studio",
    tagline: "For teams, labels, and high-volume pipelines.",
    monthly: 79,
    yearly: 64,
    features: [
      "Everything in Pro",
      "Up to 4 hours per upload",
      "5 team seats included",
      "API access & webhooks",
      "Custom voice profiles",
      "Dedicated success manager",
      "99.9% uptime SLA",
    ],
    cta: "Talk to sales",
    accent: "from-cyan-500/30 to-brand-500/20",
  },
];

export function Pricing() {
  const [yearly, setYearly] = useState(true);

  return (
    <section id="pricing" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Pricing"
          title={
            <>
              Simple plans that{" "}
              <span className="font-serif italic font-normal text-gradient-brand">
                scale with you
              </span>
            </>
          }
          description="Start free, upgrade when you're ready. Cancel anytime — no contracts, no hidden fees."
        />

        {/* Billing toggle */}
        <div className="mt-10 flex items-center justify-center gap-4">
          <span
            className={cn(
              "text-sm font-medium transition-colors",
              !yearly ? "text-white" : "text-zinc-500",
            )}
          >
            Monthly
          </span>
          <button
            type="button"
            role="switch"
            aria-checked={yearly}
            aria-label="Toggle yearly billing"
            onClick={() => setYearly((v) => !v)}
            className={cn(
              "relative h-7 w-12 rounded-full transition-colors duration-300",
              yearly ? "bg-gradient-to-r from-brand-500 to-fuchsia-500" : "bg-white/10",
            )}
          >
            <motion.span
              layout
              transition={{ type: "spring", stiffness: 500, damping: 32 }}
              className={cn(
                "absolute top-1 h-5 w-5 rounded-full bg-white shadow-lg",
                yearly ? "left-6" : "left-1",
              )}
            />
          </button>
          <span
            className={cn(
              "text-sm font-medium transition-colors",
              yearly ? "text-white" : "text-zinc-500",
            )}
          >
            Yearly
          </span>
          <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-[11px] font-semibold text-emerald-300">
            Save 20%
          </span>
        </div>

        {/* Plans */}
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 28, filter: "blur(8px)" }}
              whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className={cn(
                "relative flex flex-col rounded-3xl border p-7 backdrop-blur transition-transform duration-300 hover:-translate-y-1 sm:p-8",
                plan.popular
                  ? "border-brand-400/40 bg-gradient-to-b from-brand-500/[0.12] to-white/[0.02] shadow-[0_20px_60px_-20px_rgba(139,92,246,0.5)]"
                  : "border-white/10 bg-white/[0.03]",
              )}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-brand-500 to-fuchsia-500 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white shadow-lg shadow-brand-500/40">
                  Most popular
                </span>
              )}

              <div className="flex items-center gap-2">
                <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
                {plan.popular && <Sparkles className="h-4 w-4 text-brand-300" />}
              </div>
              <p className="mt-1 text-sm text-zinc-400">{plan.tagline}</p>

              <div className="mt-6 flex items-end gap-1.5">
                <span className="text-5xl font-semibold tracking-tight text-white">
                  ${yearly ? plan.yearly : plan.monthly}
                </span>
                <span className="mb-1.5 text-sm text-zinc-500">
                  {plan.monthly === 0 ? "forever" : "/mo"}
                </span>
              </div>
              {yearly && plan.monthly > 0 && (
                <p className="mt-1 text-xs text-zinc-500">
                  Billed annually · ${plan.yearly * 12}/yr
                </p>
              )}
              {plan.monthly === 0 && (
                <p className="mt-1 text-xs text-zinc-500">No card required</p>
              )}

              <div className="mt-6">
                <Button
                  variant={plan.popular ? "primary" : "secondary"}
                  className="w-full"
                >
                  {plan.cta}
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>

              <ul className="mt-7 space-y-3 border-t border-white/8 pt-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <span
                      className={cn(
                        "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full",
                        plan.popular
                          ? "bg-gradient-to-br from-brand-500 to-fuchsia-500"
                          : "bg-white/10",
                      )}
                    >
                      <Check className="h-3 w-3 text-white" />
                    </span>
                    <span className="text-sm text-zinc-300">{f}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <p className="mt-10 text-center text-sm text-zinc-500">
          Education and non-profit discounts available.{" "}
          <a href="#" className="text-brand-300 underline-offset-4 hover:underline">
            Contact us
          </a>
        </p>
      </div>
    </section>
  );
}

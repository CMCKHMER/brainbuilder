import { cn } from "@/utils/cn";

type WaveformProps = {
  bars?: number;
  className?: string;
  barClassName?: string;
  active?: boolean;
  playing?: boolean;
};

const HEIGHTS = [
  0.3, 0.55, 0.8, 0.45, 0.95, 0.65, 0.35, 0.7, 0.5, 0.9, 0.4, 0.6, 0.85, 0.55,
  0.3, 0.75, 0.45, 0.95, 0.6, 0.4, 0.7, 0.5, 0.85, 0.35,
];

export function Waveform({
  bars = 28,
  className,
  barClassName,
  active = true,
  playing = true,
}: WaveformProps) {
  return (
    <div
      className={cn(
        "flex items-center justify-center gap-[3px]",
        className,
      )}
      role="img"
      aria-label="Audio waveform"
    >
      {Array.from({ length: bars }).map((_, i) => {
        const h = HEIGHTS[i % HEIGHTS.length];
        return (
          <span
            key={i}
            className={cn(
              "w-full rounded-full bg-gradient-to-t from-brand-500 via-fuchsia-400 to-amber-300",
              barClassName,
            )}
            style={{
              height: `${Math.max(8, h * 100)}%`,
              animation: playing
                ? `waveform ${0.9 + (i % 5) * 0.18}s ease-in-out ${
                    i * 0.04
                  }s infinite`
                : undefined,
              opacity: active ? 1 : 0.35,
            }}
          />
        );
      })}
    </div>
  );
}

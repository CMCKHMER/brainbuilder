import { motion, type HTMLMotionProps } from "framer-motion";
import { forwardRef } from "react";
import { cn } from "@/utils/cn";

type Variant = "primary" | "secondary" | "ghost";
type Size = "sm" | "md" | "lg";

type ButtonProps = HTMLMotionProps<"button"> & {
  variant?: Variant;
  size?: Size;
  className?: string;
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-11 px-5 text-sm",
  lg: "h-14 px-7 text-base",
};

const variants: Record<Variant, string> = {
  primary:
    "text-white bg-[linear-gradient(100deg,#7c3aed,#a21caf_45%,#f59e0b)] bg-[length:200%_auto] hover:bg-[position:100%_0] shadow-[0_8px_30px_-8px_rgba(139,92,246,0.6)] hover:shadow-[0_12px_40px_-8px_rgba(217,70,239,0.7)] border border-white/10",
  secondary:
    "text-white glass-strong hover:bg-white/10 hover:border-white/20",
  ghost: "text-zinc-300 hover:text-white hover:bg-white/5",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  function Button(
    { variant = "primary", size = "md", className, children, ...props },
    ref,
  ) {
    return (
      <motion.button
        ref={ref}
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.97 }}
        transition={{ type: "spring", stiffness: 400, damping: 22 }}
        className={cn(
          "group relative inline-flex items-center justify-center gap-2 rounded-full font-medium tracking-tight transition-[background-position,box-shadow,background-color,border-color,color] duration-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#06060a] disabled:opacity-50 disabled:pointer-events-none",
          sizes[size],
          variants[variant],
          className,
        )}
        {...props}
      >
        {children}
      </motion.button>
    );
  },
);

type PillProps = {
  children: React.ReactNode;
  className?: string;
  href?: string;
};

export function PillLink({ children, className, href = "#" }: PillProps) {
  return (
    <a
      href={href}
      className={cn(
        "group relative inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-zinc-300 transition-colors hover:text-white",
        className,
      )}
    >
      {children}
    </a>
  );
}

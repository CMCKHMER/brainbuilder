export function Background() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      {/* Base gradient */}
      <div className="absolute inset-0 bg-[#06060a]" />
      <div className="absolute inset-0 bg-[radial-gradient(125%_125%_at_50%_-10%,rgba(124,58,237,0.18)_0%,rgba(6,6,10,0)_45%)]" />

      {/* Aurora orbs */}
      <div className="animate-aurora absolute -top-40 left-1/2 h-[42rem] w-[42rem] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.45),transparent_60%)] blur-3xl" />
      <div
        className="animate-aurora absolute top-1/3 -left-32 h-[34rem] w-[34rem] rounded-full bg-[radial-gradient(circle,rgba(217,70,239,0.32),transparent_60%)] blur-3xl"
        style={{ animationDelay: "-6s" }}
      />
      <div
        className="animate-aurora absolute bottom-0 right-0 h-[38rem] w-[38rem] rounded-full bg-[radial-gradient(circle,rgba(34,211,238,0.22),transparent_60%)] blur-3xl"
        style={{ animationDelay: "-11s" }}
      />
      <div
        className="animate-aurora absolute top-2/3 left-1/4 h-[28rem] w-[28rem] rounded-full bg-[radial-gradient(circle,rgba(251,191,36,0.14),transparent_60%)] blur-3xl"
        style={{ animationDelay: "-3s" }}
      />

      {/* Fine grid overlay */}
      <div className="ring-grid mask-fade-b absolute inset-0 opacity-[0.5]" />

      {/* Noise / grain via SVG */}
      <div
        className="absolute inset-0 opacity-[0.04] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        }}
      />

      {/* Top vignette */}
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/60 to-transparent" />
    </div>
  );
}

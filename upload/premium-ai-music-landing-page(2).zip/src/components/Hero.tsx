import { motion } from "framer-motion";
import {
  ArrowRight,
  Play,
  UploadCloud,
  Wand2,
  Check,
  Star,
} from "lucide-react";
import { Button } from "./ui/Button";
import { Waveform } from "./ui/Waveform";
import { cn } from "@/utils/cn";

const VERSIONS = [
  { name: "Lo-fi Remix", time: "2.4s", active: true },
  { name: "Cinematic", time: "3.1s" },
  { name: "Acoustic Cover", time: "2.8s" },
  { name: "Stems", time: "1.9s" },
];

const ease = [0.22, 1, 0.36, 1] as const;

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.08, delayChildren: 0.1 },
  },
};

const item = {
  hidden: { opacity: 0, y: 22, filter: "blur(6px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.8, ease },
  },
};

export function Hero() {
  return (
    <section id="top" className="relative pt-36 sm:pt-44 lg:pt-48">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="mx-auto flex max-w-4xl flex-col items-center text-center"
        >
          <motion.a
            variants={item}
            href="#features"
            className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-xs font-medium text-zinc-200 backdrop-blur transition-colors hover:border-white/20 hover:bg-white/10"
          >
            <span className="inline-flex h-5 items-center rounded-full bg-gradient-to-r from-brand-500 to-fuchsia-500 px-2 text-[10px] font-bold uppercase tracking-wider text-white">
              New
            </span>
            AI Stem Separation v2 is here
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
          </motion.a>

          <motion.h1
            variants={item}
            className="mt-7 text-balance text-5xl font-semibold leading-[0.98] tracking-tight text-white sm:text-6xl lg:text-7xl"
          >
            Upload a track.
            <br className="hidden sm:block" />
            <span className="text-gradient animate-gradient-pan">
              {" "}
              Release infinite
            </span>{" "}
            <span className="font-serif italic font-normal text-white">
              versions.
            </span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-6 max-w-2xl text-pretty text-lg leading-relaxed text-zinc-400 sm:text-xl"
          >
            Creative Minds Music turns any upload into remixes, covers, stems,
            and masters in seconds. The AI studio for producers, vocalists, and
            creators who ship faster.
          </motion.p>

          <motion.div
            variants={item}
            className="mt-9 flex flex-col items-center gap-3 sm:flex-row"
          >
            <Button size="lg" className="w-full sm:w-auto">
              <UploadCloud className="h-5 w-5" />
              Upload your first track
            </Button>
            <Button variant="secondary" size="lg" className="w-full sm:w-auto">
              <Play className="h-4 w-4 fill-current" />
              Watch the demo
            </Button>
          </motion.div>

          <motion.div
            variants={item}
            className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-zinc-400"
          >
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-4 w-4 text-brand-300" />
              No credit card required
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Check className="h-4 w-4 text-brand-300" />
              10 free renders
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Star className="h-4 w-4 fill-amber-300 text-amber-300" />
              4.9/5 from 2,400+ creators
            </span>
          </motion.div>
        </motion.div>

        {/* Studio visual */}
        <motion.div
          initial={{ opacity: 0, y: 60, filter: "blur(10px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 1, ease, delay: 0.4 }}
          className="relative mx-auto mt-16 max-w-5xl"
        >
          <div className="absolute -inset-x-10 -top-10 bottom-0 -z-10 rounded-[3rem] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(139,92,246,0.35),transparent_70%)] blur-2xl" />
          <StudioCard />
        </motion.div>
      </div>
    </section>
  );
}

function StudioCard() {
  return (
    <div className="glass-strong relative overflow-hidden rounded-3xl p-2 shadow-2xl">
      {/* Window chrome */}
      <div className="flex items-center justify-between px-3 py-2.5">
        <div className="flex items-center gap-1.5">
          <span className="h-3 w-3 rounded-full bg-[#ff5f57]" />
          <span className="h-3 w-3 rounded-full bg-[#febc2e]" />
          <span className="h-3 w-3 rounded-full bg-[#28c840]" />
        </div>
        <div className="flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-[11px] font-medium text-zinc-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-blink" />
          studio.creativeminds.fm
        </div>
        <div className="w-12" />
      </div>

      <div className="grid gap-3 rounded-2xl bg-ink-900/60 p-3 lg:grid-cols-[1.1fr_1fr] lg:p-4">
        {/* Left: upload + waveform */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500/30 to-fuchsia-500/20 ring-1 ring-white/10">
                <Wand2 className="h-5 w-5 text-brand-200" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  midnight_session.wav
                </p>
                <p className="text-xs text-zinc-500">
                  3:42 · 24-bit / 48kHz · 38 MB
                </p>
              </div>
            </div>
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-300">
              Ready
            </span>
          </div>

          {/* Waveform */}
          <div className="mt-5 rounded-xl bg-ink-950/60 p-4">
            <Waveform bars={36} className="h-16" />
            <div className="mt-3 flex items-center justify-between text-[11px] text-zinc-500">
              <span>0:00</span>
              <span className="font-medium text-brand-300">Analyzing…</span>
              <span>3:42</span>
            </div>
          </div>

          {/* Generate button */}
          <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[linear-gradient(100deg,#7c3aed,#a21caf_50%,#f59e0b)] bg-[length:200%_auto] py-3 text-sm font-semibold text-white transition-[background-position] duration-500 hover:bg-[position:100%_0]">
            <Wand2 className="h-4 w-4" />
            Generate versions
          </button>
        </div>

        {/* Right: versions list */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-white">Versions</p>
            <span className="text-[11px] text-zinc-500">4 results</span>
          </div>

          <div className="mt-3 space-y-2">
            {VERSIONS.map((v, i) => (
              <motion.div
                key={v.name}
                initial={{ opacity: 0, x: 14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + i * 0.12, duration: 0.5, ease }}
                className={cn(
                  "group flex cursor-pointer items-center gap-3 rounded-xl border p-2.5 transition-colors",
                  v.active
                    ? "border-brand-400/40 bg-brand-500/10"
                    : "border-white/5 bg-white/[0.02] hover:border-white/15 hover:bg-white/5",
                )}
              >
                <div
                  className={cn(
                    "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
                    v.active
                      ? "bg-gradient-to-br from-brand-500 to-fuchsia-500 text-white"
                      : "bg-white/5 text-zinc-300",
                  )}
                >
                  <Play className="h-4 w-4 fill-current" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-white">
                    {v.name}
                  </p>
                  <p className="text-[11px] text-zinc-500">
                    Generated in {v.time}
                  </p>
                </div>
                {v.active ? (
                  <span className="rounded-full bg-brand-400/20 px-2 py-0.5 text-[10px] font-semibold text-brand-200">
                    Selected
                  </span>
                ) : (
                  <ArrowRight className="h-4 w-4 text-zinc-600 transition-transform group-hover:translate-x-0.5 group-hover:text-zinc-300" />
                )}
              </motion.div>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2.5">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              <span className="text-[11px] text-zinc-400">
                Exporting lossless WAV + MP3
              </span>
            </div>
            <span className="text-[11px] font-medium text-brand-300">82%</span>
          </div>
        </div>
      </div>
    </div>
  );
}

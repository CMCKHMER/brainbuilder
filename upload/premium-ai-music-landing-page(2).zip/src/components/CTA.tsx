import { motion } from "framer-motion";
import { ArrowRight, UploadCloud } from "lucide-react";
import { Button } from "./ui/Button";
import { Waveform } from "./ui/Waveform";

export function CTA() {
  return (
    <section className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30, filter: "blur(8px)" }}
          whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-br from-brand-600/30 via-fuchsia-600/20 to-amber-500/20 p-8 text-center sm:p-14 lg:p-20"
        >
          {/* Animated background */}
          <div className="absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-ink-950/40" />
            <div className="animate-aurora absolute -top-20 left-1/4 h-72 w-72 rounded-full bg-brand-500/30 blur-3xl" />
            <div
              className="animate-aurora absolute -bottom-20 right-1/4 h-72 w-72 rounded-full bg-fuchsia-500/30 blur-3xl"
              style={{ animationDelay: "-5s" }}
            />
            <div className="ring-grid mask-fade-b absolute inset-0 opacity-30" />
          </div>

          {/* Floating waveform decoration */}
          <div className="absolute inset-x-0 top-6 mx-auto flex max-w-md justify-center opacity-30">
            <Waveform bars={24} className="h-6" />
          </div>

          <div className="relative">
            <h2 className="mx-auto max-w-3xl text-balance text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-6xl">
              Your next release is one{" "}
              <span className="font-serif italic font-normal text-white">
                upload
              </span>{" "}
              away
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-zinc-200 sm:text-lg">
              Join 50,000+ creators turning uploads into infinite versions.
              Start free — no credit card, no commitment.
            </p>

            <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button size="lg" className="w-full sm:w-auto">
                <UploadCloud className="h-5 w-5" />
                Upload your first track
              </Button>
              <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                Book a demo
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-zinc-300">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                10 free renders, forever
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Cancel anytime
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                100% yours to monetize
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

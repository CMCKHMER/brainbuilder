import { motion, useInView, useMotionValue, useSpring } from "framer-motion";
import { useEffect, useRef } from "react";

const LOGOS = [
  "Spotify",
  "Apple Music",
  "SoundCloud",
  "Bandlab",
  "Ableton",
  "TikTok",
  "YouTube",
  "Bandcamp",
];

const STATS = [
  { value: 2.4, suffix: "M+", label: "Tracks transformed" },
  { value: 50, suffix: "K+", label: "Active creators" },
  { value: 4.9, suffix: "/5", label: "Average rating" },
  { value: 190, suffix: "+", label: "Countries served" },
];

function Counter({ value, suffix }: { value: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const mv = useMotionValue(0);
  const spring = useSpring(mv, { duration: 1600, bounce: 0 });

  useEffect(() => {
    if (inView) mv.set(value);
  }, [inView, value, mv]);

  useEffect(() => {
    return spring.on("change", (v) => {
      if (ref.current) {
        const decimals = value % 1 !== 0 ? 1 : 0;
        ref.current.textContent = v.toFixed(decimals) + suffix;
      }
    });
  }, [spring, value, suffix]);

  return <span ref={ref}>0{suffix}</span>;
}

export function SocialProof() {
  return (
    <section className="relative mt-24 border-y border-white/5 py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-medium uppercase tracking-[0.22em] text-zinc-500">
          Trusted by creators shipping to every major platform
        </p>

        {/* Marquee */}
        <div className="mask-fade-edges relative mt-8 overflow-hidden">
          <div className="animate-marquee flex w-max items-center gap-14 pr-14">
            {[...LOGOS, ...LOGOS].map((logo, i) => (
              <span
                key={i}
                className="text-xl font-semibold tracking-tight text-zinc-500/80 transition-colors hover:text-zinc-200"
                style={{ fontFamily: "var(--font-sans)" }}
              >
                {logo}
              </span>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/5 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.6 }}
              className="bg-ink-900/40 px-6 py-8 text-center backdrop-blur"
            >
              <div className="text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                <Counter value={s.value} suffix={s.suffix} />
              </div>
              <div className="mt-2 text-sm text-zinc-400">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Logo } from "./ui/Logo";
import { Waveform } from "./ui/Waveform";

const FOOTER_LINKS = [
  {
    title: "Product",
    links: [
      { label: "Features", href: "#features" },
      { label: "Showcase", href: "#showcase" },
      { label: "Pricing", href: "#pricing" },
      { label: "Changelog", href: "#" },
      { label: "Roadmap", href: "#" },
    ],
  },
  {
    title: "Use cases",
    links: [
      { label: "For Producers", href: "#benefits" },
      { label: "For Vocalists", href: "#benefits" },
      { label: "For Creators", href: "#benefits" },
      { label: "For Labels", href: "#" },
      { label: "For Educators", href: "#" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Documentation", href: "#" },
      { label: "Tutorials", href: "#" },
      { label: "API reference", href: "#" },
      { label: "Community", href: "#" },
      { label: "Status", href: "#" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "#" },
      { label: "Blog", href: "#" },
      { label: "Careers", href: "#" },
      { label: "Press kit", href: "#" },
      { label: "Contact", href: "#" },
    ],
  },
];

const SOCIALS = ["Twitter", "Instagram", "YouTube", "TikTok", "Discord"];

export function Footer() {
  return (
    <footer className="relative border-t border-white/8 pt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2.6fr]">
          {/* Brand + newsletter */}
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-zinc-400">
              The AI music studio for creators. Upload any track and transform it
              into infinite versions — remixes, covers, stems, and masters in
              seconds.
            </p>

            {/* Newsletter */}
            <form className="mt-6 max-w-sm" onSubmit={(e) => e.preventDefault()}>
              <label className="text-xs font-medium uppercase tracking-wider text-zinc-500">
                Get product updates
              </label>
              <div className="mt-2 flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] p-1.5 pl-4 focus-within:border-brand-400/40">
                <input
                  type="email"
                  placeholder="you@studio.com"
                  className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder:text-zinc-500 focus:outline-none"
                  aria-label="Email address"
                />
                <button
                  type="submit"
                  className="shrink-0 rounded-full bg-gradient-to-r from-brand-500 to-fuchsia-500 px-4 py-2 text-sm font-medium text-white transition-transform hover:scale-[1.03]"
                >
                  Subscribe
                </button>
              </div>
              <p className="mt-2 text-xs text-zinc-500">
                No spam. Unsubscribe anytime.
              </p>
            </form>

            {/* Decorative waveform */}
            <div className="mt-8 flex max-w-xs items-center gap-2 opacity-60">
              <span className="text-xs text-zinc-500">Now playing</span>
              <Waveform bars={20} className="h-3 flex-1" />
            </div>
          </div>

          {/* Link columns */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {FOOTER_LINKS.map((col) => (
              <div key={col.title}>
                <h4 className="text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500">
                  {col.title}
                </h4>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        className="text-sm text-zinc-400 transition-colors hover:text-white"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 flex flex-col items-center justify-between gap-6 border-t border-white/8 py-8 sm:flex-row">
          <div className="flex flex-col items-center gap-2 sm:flex-row sm:gap-4">
            <p className="text-sm text-zinc-500">
              © {new Date().getFullYear()} Creative Minds Music. All rights reserved.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-zinc-600">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-blink" />
              All systems operational
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            {SOCIALS.map((s) => (
              <a
                key={s}
                href="#"
                className="rounded-full border border-white/10 bg-white/[0.02] px-3 py-1.5 text-xs font-medium text-zinc-400 transition-colors hover:border-white/20 hover:text-white"
              >
                {s}
              </a>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-3 pb-8 sm:flex-row">
          <div className="flex gap-5 text-xs text-zinc-600">
            <a href="#" className="transition-colors hover:text-zinc-300">
              Privacy
            </a>
            <a href="#" className="transition-colors hover:text-zinc-300">
              Terms
            </a>
            <a href="#" className="transition-colors hover:text-zinc-300">
              Cookies
            </a>
            <a href="#" className="transition-colors hover:text-zinc-300">
              Licenses
            </a>
          </div>
          <p className="text-xs text-zinc-600">
            Made with care for creators everywhere.
          </p>
        </div>
      </div>
    </footer>
  );
}

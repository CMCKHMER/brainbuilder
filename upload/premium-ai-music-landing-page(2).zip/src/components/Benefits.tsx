import { motion } from "framer-motion";
import {
  Headphones,
  Mic,
  Video,
  TrendingUp,
  Clock,
  Palette,
  Check,
} from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { Reveal } from "./ui/Reveal";
import { Waveform } from "./ui/Waveform";
import { cn } from "@/utils/cn";

type Benefit = {
  audience: string;
  title: string;
  desc: string;
  bullets: string[];
  icon: React.ComponentType<{ className?: string }>;
  accent: string;
  visual: "producer" | "vocalist" | "creator";
};

const BENEFITS: Benefit[] = [
  {
    audience: "For Producers",
    title: "Ship beats and remixes in minutes, not weekends",
    desc: "Stop rebuilding sessions from scratch. Upload a reference, generate variations, and deliver more options to clients without burning out.",
    bullets: [
      "Generate 10 remix variations from one stem pack",
      "Match key and tempo automatically across versions",
      "Export DAW-ready sessions for Ableton, Logic, and FL",
    ],
    icon: Headphones,
    accent: "from-brand-500/30 to-fuchsia-500/20",
    visual: "producer",
  },
  {
    audience: "For Vocalists",
    title: "Hear yourself in any song, any style",
    desc: "Reimagine your voice across genres and arrangements. Build a demo library, practice covers, or create alternate takes without a producer in the room.",
    bullets: [
      "Convert your vocal to any timbre or style",
      "Generate practice tracks in your range",
      "Create cover versions without licensing headaches",
    ],
    icon: Mic,
    accent: "from-fuchsia-500/30 to-amber-500/20",
    visual: "vocalist",
  },
  {
    audience: "For Content Creators",
    title: "Never run out of original audio again",
    desc: "Turn one upload into a week of content. Stems for edits, covers for trends, and royalty-free masters that are fully yours.",
    bullets: [
      "Spin up 15-second clips for TikTok in one click",
      "Get fully cleared, royalty-free masters",
      "Batch-generate versions for every platform",
    ],
    icon: Video,
    accent: "from-cyan-500/30 to-brand-500/20",
    visual: "creator",
  },
];

export function Benefits() {
  return (
    <section id="benefits" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Who it's for"
          title={
            <>
              Built for every kind of{" "}
              <span className="font-serif italic font-normal text-gradient-brand">
                music mind
              </span>
            </>
          }
          description="Whether you produce, perform, or post — Creative Minds Music adapts to how you create."
        />

        <div className="mt-20 flex flex-col gap-24 lg:gap-32">
          {BENEFITS.map((b, i) => (
            <BenefitRow key={b.audience} benefit={b} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function BenefitRow({ benefit, index }: { benefit: Benefit; index: number }) {
  const reverse = index % 2 === 1;
  return (
    <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
      <Reveal className={cn(reverse && "lg:order-2")}>
        <div>
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ring-1 ring-white/10",
                benefit.accent,
              )}
            >
              <benefit.icon className="h-5 w-5 text-white" />
            </div>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-300">
              {benefit.audience}
            </span>
          </div>
          <h3 className="mt-5 text-balance text-3xl font-semibold leading-tight tracking-tight text-white sm:text-4xl">
            {benefit.title}
          </h3>
          <p className="mt-4 max-w-xl text-pretty text-base leading-relaxed text-zinc-400 sm:text-lg">
            {benefit.desc}
          </p>
          <ul className="mt-7 space-y-3">
            {benefit.bullets.map((bullet) => (
              <li key={bullet} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-fuchsia-500">
                  <Check className="h-3 w-3 text-white" />
                </span>
                <span className="text-sm text-zinc-300 sm:text-base">
                  {bullet}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </Reveal>

      <Reveal delay={0.1} className={cn(reverse && "lg:order-1")}>
        <BenefitVisual type={benefit.visual} accent={benefit.accent} />
      </Reveal>
    </div>
  );
}

function BenefitVisual({
  type,
  accent,
}: {
  type: Benefit["visual"];
  accent: string;
}) {
  return (
    <div className="relative">
      <div
        className={cn(
          "absolute -inset-4 -z-10 rounded-3xl bg-gradient-to-br opacity-40 blur-2xl",
          accent,
        )}
      />
      <div className="glass-strong overflow-hidden rounded-3xl p-2">
        <div className="rounded-2xl bg-ink-950/60 p-6 sm:p-8">
          {type === "producer" && <ProducerVisual />}
          {type === "vocalist" && <VocalistVisual />}
          {type === "creator" && <CreatorVisual />}
        </div>
      </div>
    </div>
  );
}

function ProducerVisual() {
  const tracks = [
    { name: "Original", bpm: 120, key: "C min" },
    { name: "Trap Remix", bpm: 140, key: "C min" },
    { name: "House Mix", bpm: 124, key: "C# min" },
    { name: "Lo-fi Cut", bpm: 78, key: "C min" },
  ];
  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <p className="text-sm font-semibold text-white">Version library</p>
        <TrendingUp className="h-4 w-4 text-emerald-400" />
      </div>
      <div className="space-y-2.5">
        {tracks.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 + i * 0.08 }}
            className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-3"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5">
              <span className="text-[10px] font-bold text-brand-300">
                {t.bpm}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-white">{t.name}</p>
              <Waveform bars={20} className="mt-1.5 h-3" />
            </div>
            <span className="rounded-md bg-white/5 px-2 py-1 text-[10px] text-zinc-400">
              {t.key}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function VocalistVisual() {
  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <p className="text-sm font-semibold text-white">Voice profiles</p>
        <Palette className="h-4 w-4 text-fuchsia-400" />
      </div>
      <div className="grid grid-cols-2 gap-3">
        {[
          { name: "Warm Alto", mood: "Soulful" },
          { name: "Bright Tenor", mood: "Pop" },
          { name: "Airy Soprano", mood: "Cinematic" },
          { name: "Deep Bass", mood: "Jazz" },
        ].map((v, i) => (
          <motion.div
            key={v.name}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 + i * 0.08 }}
            className="rounded-xl border border-white/8 bg-white/[0.02] p-4"
          >
            <div className="mb-3 flex h-10 items-center justify-center rounded-lg bg-gradient-to-br from-fuchsia-500/20 to-brand-500/20">
              <Mic className="h-4 w-4 text-fuchsia-300" />
            </div>
            <p className="text-sm font-medium text-white">{v.name}</p>
            <p className="text-[11px] text-zinc-500">{v.mood}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-3 rounded-xl border border-white/8 bg-white/[0.02] p-3">
        <Waveform bars={32} className="h-8" />
      </div>
    </div>
  );
}

function CreatorVisual() {
  const platforms = [
    { name: "TikTok", clips: 12, reach: "2.4M" },
    { name: "Reels", clips: 8, reach: "1.1M" },
    { name: "Shorts", clips: 6, reach: "890K" },
  ];
  return (
    <div>
      <div className="mb-5 flex items-center justify-between">
        <p className="text-sm font-semibold text-white">Content pipeline</p>
        <Clock className="h-4 w-4 text-cyan-400" />
      </div>
      <div className="grid grid-cols-3 gap-2.5">
        {platforms.map((p, i) => (
          <motion.div
            key={p.name}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 + i * 0.08 }}
            className="rounded-xl border border-white/8 bg-white/[0.02] p-3 text-center"
          >
            <p className="text-sm font-semibold text-white">{p.clips}</p>
            <p className="text-[10px] text-zinc-500">clips</p>
            <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
              <div className="h-full bg-gradient-to-r from-cyan-400 to-brand-400" style={{ width: `${60 + i * 12}%` }} />
            </div>
            <p className="mt-2 text-[10px] font-medium text-cyan-300">{p.reach}</p>
            <p className="text-[9px] text-zinc-600">{p.name}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-400/20 bg-emerald-400/5 p-3">
        <Check className="h-4 w-4 text-emerald-400" />
        <p className="text-xs text-zinc-300">
          26 clips auto-generated from 1 upload this week
        </p>
      </div>
    </div>
  );
}

import { motion } from "framer-motion";
import {
  Scissors,
  Mic2,
  Disc3,
  Waves,
  Cloud,
  Users,
  ArrowUpRight,
} from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { Stagger, StaggerItem } from "./ui/Reveal";
import { Waveform } from "./ui/Waveform";
import { cn } from "@/utils/cn";

type Feature = {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  accent: string;
  featured?: boolean;
};

const FEATURES: Feature[] = [
  {
    icon: Scissors,
    title: "AI Stem Separation",
    desc: "Split any track into vocals, drums, bass, and instruments in seconds. Studio-grade isolation with zero artifacts.",
    accent: "from-brand-500/30 to-fuchsia-500/20",
    featured: true,
  },
  {
    icon: Mic2,
    title: "Voice Conversion",
    desc: "Reimagine any vocal in a different timbre, gender, or style while preserving emotion and phrasing.",
    accent: "from-cyan-500/30 to-brand-500/20",
  },
  {
    icon: Disc3,
    title: "Genre Remixing",
    desc: "Turn a pop track into lo-fi, trap, orchestral, or house with one click. Arrangement-aware AI.",
    accent: "from-amber-500/30 to-fuchsia-500/20",
  },
  {
    icon: Waves,
    title: "Smart Mastering",
    desc: "Loud, clean, streaming-ready masters tuned to LUFS targets for Spotify, Apple, and YouTube.",
    accent: "from-emerald-500/30 to-cyan-500/20",
  },
  {
    icon: Cloud,
    title: "Cloud Library",
    desc: "Every upload and version is stored securely. Access, version, and export from anywhere, anytime.",
    accent: "from-brand-500/30 to-cyan-500/20",
  },
  {
    icon: Users,
    title: "Real-time Collab",
    desc: "Invite bandmates and clients to comment, approve, and iterate on versions together.",
    accent: "from-fuchsia-500/30 to-amber-500/20",
  },
];

export function Features() {
  return (
    <section id="features" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Features"
          title={
            <>
              Everything you need to{" "}
              <span className="font-serif italic font-normal text-gradient-brand">
                reimagine
              </span>{" "}
              a track
            </>
          }
          description="A complete AI toolkit for music transformation — upload once, generate endlessly, export anywhere."
        />

        <Stagger className="mt-16 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <StaggerItem
              key={f.title}
              className={cn(f.featured && "lg:col-span-2 lg:row-span-2")}
            >
              <FeatureCard feature={f} />
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}

function FeatureCard({ feature }: { feature: Feature }) {
  const { icon: Icon, title, desc, accent, featured } = feature;
  return (
    <motion.article
      whileHover={{ y: -4 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={cn(
        "group relative h-full overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur transition-colors duration-300 hover:border-white/20 hover:bg-white/[0.05]",
        featured && "flex flex-col justify-between sm:p-8",
      )}
    >
      {/* hover glow */}
      <div
        className={cn(
          "pointer-events-none absolute -inset-px -z-10 rounded-2xl bg-gradient-to-br opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100",
          accent,
        )}
      />

      <div className="flex items-start justify-between">
        <div
          className={cn(
            "inline-flex items-center justify-center rounded-xl bg-gradient-to-br ring-1 ring-white/10",
            accent,
            featured ? "h-14 w-14" : "h-11 w-11",
          )}
        >
          <Icon
            className={cn("text-white", featured ? "h-7 w-7" : "h-5 w-5")}
          />
        </div>
        <ArrowUpRight className="h-5 w-5 text-zinc-600 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-white" />
      </div>

      <div className="mt-5">
        <h3
          className={cn(
            "font-semibold tracking-tight text-white",
            featured ? "text-2xl sm:text-3xl" : "text-lg",
          )}
        >
          {title}
        </h3>
        <p
          className={cn(
            "mt-2 text-pretty text-zinc-400",
            featured ? "text-base sm:text-lg" : "text-sm leading-relaxed",
          )}
        >
          {desc}
        </p>
      </div>

      {featured && (
        <div className="mt-8 rounded-2xl border border-white/10 bg-ink-950/50 p-5">
          <div className="mb-3 flex items-center justify-between text-xs text-zinc-500">
            <span>Stems · midnight_session.wav</span>
            <span className="text-brand-300">4 tracks</span>
          </div>
          <div className="space-y-2.5">
            {[
              { name: "Vocals", color: "from-brand-400 to-fuchsia-400", h: 14 },
              { name: "Drums", color: "from-amber-400 to-orange-400", h: 12 },
              { name: "Bass", color: "from-cyan-400 to-brand-400", h: 12 },
              { name: "Other", color: "from-emerald-400 to-cyan-400", h: 12 },
            ].map((stem) => (
              <div key={stem.name} className="flex items-center gap-3">
                <span className="w-14 shrink-0 text-[11px] font-medium text-zinc-400">
                  {stem.name}
                </span>
                <Waveform
                  bars={28}
                  className="h-4 flex-1"
                  barClassName={cn(
                    "bg-gradient-to-t",
                    stem.color,
                  )}
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </motion.article>
  );
}

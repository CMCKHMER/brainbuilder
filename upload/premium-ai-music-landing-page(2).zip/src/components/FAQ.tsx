import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { cn } from "@/utils/cn";

const FAQS = [
  {
    q: "What file formats can I upload?",
    a: "WAV, MP3, FLAC, AIFF, OGG, and M4A — up to 2 GB per file and 4 hours in length on the Studio plan. We automatically normalize and prep your audio for the best model performance.",
  },
  {
    q: "How long does it take to generate versions?",
    a: "Most versions render in under 4 seconds per minute of audio on the Pro plan. Studio customers get a priority GPU queue that cuts that roughly in half. You'll see a live progress bar in the studio.",
  },
  {
    q: "Who owns the versions I create?",
    a: "You do. Every version, stem, and master you generate is 100% yours to use, distribute, and monetize — including on commercial releases. We never claim rights to your output.",
  },
  {
    q: "Can I use the output commercially?",
    a: "Yes. All paid plans include a commercial license covering streaming, sync, and physical release. Starter plan output is licensed for non-commercial use only.",
  },
  {
    q: "What's the difference between Pro and Studio?",
    a: "Pro is built for individual creators with unlimited renders and lossless export. Studio adds team collaboration, API access, custom voice profiles, a dedicated success manager, and a 99.9% uptime SLA for high-volume pipelines.",
  },
  {
    q: "Do you store my original uploads?",
    a: "Your originals are encrypted at rest and private by default. You can delete them — and all derived versions — permanently at any time. We never use your audio to train models.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Absolutely. Plans are month-to-month (or annual, if you choose). Cancel from your dashboard in two clicks — no phone calls, no retention scripts. You keep access until the end of your billing period.",
  },
  {
    q: "Do you offer student or non-profit discounts?",
    a: "Yes — 50% off Pro for verified students and educators, and custom pricing for non-profits and accredited institutions. Reach out to our team and we'll get you set up.",
  },
];

function FAQItem({
  item,
  open,
  onToggle,
}: {
  item: { q: string; a: string };
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border transition-colors duration-300",
        open
          ? "border-brand-400/30 bg-white/[0.05]"
          : "border-white/8 bg-white/[0.02] hover:border-white/15",
      )}
    >
      <button
        type="button"
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left sm:px-6 sm:py-6"
        aria-expanded={open}
      >
        <span className="text-[15px] font-medium text-white sm:text-base">
          {item.q}
        </span>
        <span
          className={cn(
            "flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-all duration-300",
            open
              ? "bg-gradient-to-br from-brand-500 to-fuchsia-500 text-white"
              : "bg-white/5 text-zinc-400",
          )}
        >
          {open ? (
            <Minus className="h-4 w-4" />
          ) : (
            <Plus className="h-4 w-4" />
          )}
        </span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <p className="px-5 pb-5 text-sm leading-relaxed text-zinc-400 sm:px-6 sm:pb-6 sm:text-[15px]">
              {item.a}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="FAQ"
          title={
            <>
              Questions, answered
            </>
          }
          description="Everything you need to know about Creative Minds Music. Still curious? Reach out anytime."
        />

        <div className="mt-12 flex flex-col gap-3">
          {FAQS.map((item, i) => (
            <FAQItem
              key={item.q}
              item={item}
              open={openIndex === i}
              onToggle={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center gap-3 rounded-2xl border border-white/8 bg-white/[0.02] p-6 text-center sm:flex-row sm:justify-between sm:text-left">
          <div>
            <p className="text-sm font-semibold text-white">
              Still have questions?
            </p>
            <p className="text-sm text-zinc-400">
              Our team replies within a few hours, every day.
            </p>
          </div>
          <a
            href="#"
            className="rounded-full bg-white/5 px-5 py-2.5 text-sm font-medium text-white ring-1 ring-white/10 transition-colors hover:bg-white/10"
          >
            Contact support
          </a>
        </div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { Stagger, StaggerItem } from "./ui/Reveal";
import { cn } from "@/utils/cn";

type Testimonial = {
  quote: string;
  name: string;
  role: string;
  initials: string;
  accent: string;
  rating: number;
};

const FEATURED: Testimonial = {
  quote:
    "I uploaded a rough demo at 2am and had four fully produced versions on my manager's desk by morning. Creative Minds Music didn't just speed up my workflow — it changed what I can say yes to.",
  name: "Maya Okafor",
  role: "Singer-songwriter · Sony/ATV",
  initials: "MO",
  accent: "from-brand-500 to-fuchsia-500",
  rating: 5,
};

const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      "The stem separation is unreal. I've tried every tool out there and nothing comes close to this clean. My remix turnaround dropped from days to hours.",
    name: "Diego Marín",
    role: "Producer · 12M streams",
    initials: "DM",
    accent: "from-cyan-500 to-brand-500",
    rating: 5,
  },
  {
    quote:
      "As a vocalist, being able to hear myself in any arrangement before booking studio time is a superpower. I demo ten songs in the time it used to take to do one.",
    name: "Priya Raman",
    role: "Vocalist · Independent",
    initials: "PR",
    accent: "from-fuchsia-500 to-amber-500",
    rating: 5,
  },
  {
    quote:
      "We push 30+ clips a week across TikTok and Reels. Creative Minds Music is the only thing keeping our content pipeline fed without a dedicated audio team.",
    name: "Theo Lindqvist",
    role: "Head of Content · Lumen Media",
    initials: "TL",
    accent: "from-amber-500 to-fuchsia-500",
    rating: 5,
  },
];

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={cn(
            "h-3.5 w-3.5",
            i < rating
              ? "fill-amber-300 text-amber-300"
              : "fill-white/10 text-white/10",
          )}
        />
      ))}
    </div>
  );
}

function Avatar({ initials, accent }: { initials: string; accent: string }) {
  return (
    <div className="relative">
      <div
        className={cn(
          "flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br text-sm font-semibold text-white ring-2 ring-white/10",
          accent,
        )}
      >
        {initials}
      </div>
    </div>
  );
}

export function Testimonials() {
  return (
    <section className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Loved by creators"
          title={
            <>
              The studio creators{" "}
              <span className="font-serif italic font-normal text-gradient-brand">
                keep coming back
              </span>{" "}
              to
            </>
          }
          description="Over 50,000 producers, vocalists, and content teams rely on Creative Minds Music every day."
        />

        {/* Featured testimonial */}
        <motion.div
          initial={{ opacity: 0, y: 30, filter: "blur(8px)" }}
          whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="relative mt-16 overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.06] to-white/[0.01] p-8 backdrop-blur sm:p-12"
        >
          <div className="absolute -right-10 -top-10 -z-10 h-48 w-48 rounded-full bg-gradient-to-br from-brand-500/30 to-fuchsia-500/20 blur-3xl" />
          <Quote className="h-10 w-10 text-brand-400/60" />
          <div className="mt-6 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <blockquote className="max-w-3xl text-balance text-xl font-medium leading-relaxed text-white sm:text-2xl">
              "{FEATURED.quote}"
            </blockquote>
            <div className="flex shrink-0 items-center gap-4 lg:flex-col lg:items-end lg:gap-3">
              <Avatar initials={FEATURED.initials} accent={FEATURED.accent} />
              <div className="lg:text-right">
                <p className="text-sm font-semibold text-white">
                  {FEATURED.name}
                </p>
                <p className="text-xs text-zinc-400">{FEATURED.role}</p>
              </div>
            </div>
          </div>
          <div className="mt-6">
            <Stars rating={FEATURED.rating} />
          </div>
        </motion.div>

        {/* Card grid */}
        <Stagger className="mt-6 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <StaggerItem key={t.name}>
              <motion.figure
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 22 }}
                className="group flex h-full flex-col rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur transition-colors duration-300 hover:border-white/20 hover:bg-white/[0.05]"
              >
                <Stars rating={t.rating} />
                <blockquote className="mt-4 flex-1 text-pretty text-[15px] leading-relaxed text-zinc-300">
                  "{t.quote}"
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-white/8 pt-5">
                  <Avatar initials={t.initials} accent={t.accent} />
                  <div>
                    <p className="text-sm font-semibold text-white">{t.name}</p>
                    <p className="text-xs text-zinc-400">{t.role}</p>
                  </div>
                </figcaption>
              </motion.figure>
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}

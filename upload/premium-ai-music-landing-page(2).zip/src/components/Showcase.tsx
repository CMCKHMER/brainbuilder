import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { UploadCloud, Wand2, Download, Check } from "lucide-react";
import { SectionHeading } from "./ui/SectionHeading";
import { Waveform } from "./ui/Waveform";
import { cn } from "@/utils/cn";

type Step = {
  id: string;
  step: string;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
};

const STEPS: Step[] = [
  {
    id: "upload",
    step: "01",
    title: "Upload any track",
    desc: "Drag in WAV, MP3, FLAC, or AIFF. Up to 2 GB per file, up to 4 hours long. We handle the rest.",
    icon: UploadCloud,
  },
  {
    id: "transform",
    step: "02",
    title: "Transform with AI",
    desc: "Choose your versions — remixes, covers, stems, masters. Our models analyze arrangement and generate in seconds.",
    icon: Wand2,
  },
  {
    id: "export",
    step: "03",
    title: "Export & release",
    desc: "Download lossless stems, full mixes, or social-ready clips. Push straight to Spotify, TikTok, or your DAW.",
    icon: Download,
  },
];

export function Showcase() {
  const [active, setActive] = useState(0);
  const step = STEPS[active];

  return (
    <section id="showcase" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="How it works"
          title={
            <>
              From upload to release in{" "}
              <span className="font-serif italic font-normal text-gradient-brand">
                three moves
              </span>
            </>
          }
          description="No plugins, no DAW required. A studio that lives in your browser and ships at the speed of thought."
        />

        <div className="mt-16 grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-12">
          {/* Steps */}
          <div className="flex flex-col gap-3">
            {STEPS.map((s, i) => {
              const isActive = i === active;
              return (
                <button
                  key={s.id}
                  onClick={() => setActive(i)}
                  className={cn(
                    "group relative overflow-hidden rounded-2xl border p-5 text-left transition-all duration-300 sm:p-6",
                    isActive
                      ? "border-white/20 bg-white/[0.06]"
                      : "border-white/8 bg-white/[0.02] hover:border-white/15 hover:bg-white/[0.04]",
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="step-glow"
                      className="pointer-events-none absolute inset-0 -z-10 rounded-2xl bg-[radial-gradient(120%_120%_at_0%_0%,rgba(139,92,246,0.18),transparent_60%)]"
                    />
                  )}
                  <div className="flex items-start gap-4">
                    <div
                      className={cn(
                        "relative flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ring-1 transition-all duration-300",
                        isActive
                          ? "bg-gradient-to-br from-brand-500 to-fuchsia-500 ring-white/20"
                          : "bg-white/5 ring-white/10",
                      )}
                    >
                      <s.icon
                        className={cn(
                          "h-5 w-5 transition-colors",
                          isActive ? "text-white" : "text-zinc-300",
                        )}
                      />
                      {isActive && (
                        <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-400 text-[9px] font-bold text-emerald-950">
                          <Check className="h-2.5 w-2.5" />
                        </span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            "text-xs font-semibold tracking-wider transition-colors",
                            isActive ? "text-brand-300" : "text-zinc-600",
                          )}
                        >
                          {s.step}
                        </span>
                        <span className="h-1 w-1 rounded-full bg-zinc-700" />
                        <span className="text-[11px] uppercase tracking-wider text-zinc-500">
                          Step
                        </span>
                      </div>
                      <h3 className="mt-1 text-lg font-semibold tracking-tight text-white sm:text-xl">
                        {s.title}
                      </h3>
                      <AnimatePresence mode="wait">
                        {isActive && (
                          <motion.p
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="mt-2 overflow-hidden text-sm leading-relaxed text-zinc-400"
                          >
                            {s.desc}
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Visual */}
          <div className="relative">
            <div className="glass-strong relative h-full overflow-hidden rounded-3xl p-2">
              <div className="relative h-full overflow-hidden rounded-2xl bg-ink-950/60 p-6 sm:p-8">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, y: 16, filter: "blur(8px)" }}
                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                    exit={{ opacity: 0, y: -16, filter: "blur(8px)" }}
                    transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  >
                    {active === 0 && <UploadVisual />}
                    {active === 1 && <TransformVisual />}
                    {active === 2 && <ExportVisual />}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
            <div className="absolute -inset-x-6 -bottom-6 -top-6 -z-10 rounded-[2.5rem] bg-[radial-gradient(60%_60%_at_50%_100%,rgba(217,70,239,0.2),transparent_70%)] blur-2xl" />
          </div>
        </div>
      </div>
    </section>
  );
}

function UploadVisual() {
  return (
    <div className="flex h-full flex-col">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-white">Upload a track</p>
          <p className="text-xs text-zinc-500">Drag & drop or browse</p>
        </div>
        <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] text-zinc-400">
          Max 2 GB
        </span>
      </div>
      <div className="relative flex flex-1 items-center justify-center rounded-2xl border-2 border-dashed border-white/15 bg-white/[0.02] p-10">
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-4">
            <span className="absolute inset-0 animate-ping rounded-2xl bg-brand-500/30" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-fuchsia-500 shadow-lg shadow-brand-500/30">
              <UploadCloud className="h-7 w-7 text-white" />
            </div>
          </div>
          <p className="text-sm font-medium text-white">
            Drop your file here
          </p>
          <p className="mt-1 text-xs text-zinc-500">
            WAV · MP3 · FLAC · AIFF · up to 4 hours
          </p>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-2 text-xs text-zinc-500">
        <Check className="h-3.5 w-3.5 text-emerald-400" />
        End-to-end encrypted · Private by default
      </div>
    </div>
  );
}

function TransformVisual() {
  const versions = [
    { name: "Lo-fi Remix", tag: "Remix" },
    { name: "Cinematic", tag: "Remix" },
    { name: "Acoustic Cover", tag: "Cover" },
    { name: "Stems Pack", tag: "Stems" },
  ];
  return (
    <div className="flex h-full flex-col">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-white">Generating versions</p>
          <p className="text-xs text-zinc-500">4 models running in parallel</p>
        </div>
        <span className="rounded-full border border-brand-400/30 bg-brand-500/10 px-3 py-1 text-[11px] font-medium text-brand-200">
          68% complete
        </span>
      </div>

      <div className="rounded-2xl bg-ink-950/60 p-4">
        <Waveform bars={32} className="h-14" />
        <div className="mt-3 h-1 overflow-hidden rounded-full bg-white/10">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-brand-500 via-fuchsia-500 to-amber-400"
            initial={{ width: "0%" }}
            animate={{ width: "68%" }}
            transition={{ duration: 1.2, ease: "easeOut" }}
          />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5">
        {versions.map((v, i) => (
          <motion.div
            key={v.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 + i * 0.1 }}
            className="flex items-center gap-2 rounded-xl border border-white/8 bg-white/[0.02] p-3"
          >
            <span className="h-2 w-2 animate-blink rounded-full bg-emerald-400" />
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-medium text-white">{v.name}</p>
              <p className="text-[10px] text-zinc-500">{v.tag}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function ExportVisual() {
  const formats = [
    { name: "Stems · WAV", size: "312 MB", ready: true },
    { name: "Full Mix · WAV", size: "84 MB", ready: true },
    { name: "Social · MP3 320", size: "9 MB", ready: true },
    { name: "TikTok · 15s clip", size: "2 MB", ready: false },
  ];
  return (
    <div className="flex h-full flex-col">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-white">Export & release</p>
          <p className="text-xs text-zinc-500">Choose formats and destinations</p>
        </div>
        <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium text-emerald-300">
          Ready to ship
        </span>
      </div>

      <div className="space-y-2">
        {formats.map((f, i) => (
          <motion.div
            key={f.name}
            initial={{ opacity: 0, x: 14 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 + i * 0.08 }}
            className="flex items-center justify-between rounded-xl border border-white/8 bg-white/[0.02] px-4 py-3"
          >
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-lg",
                  f.ready
                    ? "bg-emerald-400/15 text-emerald-300"
                    : "bg-white/5 text-zinc-400",
                )}
              >
                {f.ready ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <span className="h-2 w-2 animate-blink rounded-full bg-amber-400" />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{f.name}</p>
                <p className="text-[11px] text-zinc-500">{f.size}</p>
              </div>
            </div>
            <button className="rounded-lg px-3 py-1.5 text-xs font-medium text-brand-300 transition-colors hover:bg-brand-500/10 hover:text-brand-200">
              Download
            </button>
          </motion.div>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between rounded-xl border border-white/8 bg-white/[0.02] px-4 py-3">
        <span className="text-xs text-zinc-400">Publish directly to</span>
        <div className="flex gap-2">
          {["Spotify", "TikTok", "YouTube"].map((p) => (
            <span
              key={p}
              className="rounded-full bg-white/5 px-2.5 py-1 text-[10px] font-medium text-zinc-300"
            >
              {p}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
